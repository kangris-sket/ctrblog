<body <?php body_class(); ?>>
<div id="container">
	<div id="header">
    	<?php
        if(isset($headerImg)){
			$sitename = strip_tags($sitename);
			echo "<img src='$headerImg' alt='$sitename' />";
		}else{
			$heading_tag = ( is_home() || is_front_page() ) ? 'h1' : 'div'; ?>
        <div id="branding">
        <<?php echo $heading_tag; ?> id="site-title">
            <a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo $sitename; ?></span></a>
        </<?php echo $heading_tag; ?>>
        </div>
        <div id="tagline"><?php echo $tagline; ?></div>
        <?php } ?>
    </div>
    <div id="main">
    	<div id="menuBar" style="background:<?php echo $lu_bg; ?>;">
    	<?php if($use_tagline || !$ads['728 link unit'] || !$layout){}else echo "<div id='leader_lu'>{$ads['728 link unit']}</div>"; ?>
    </div>
        <div id="leftCol">
            <?php get_sidebar(); ?>
        </div>
        <div id="rightCol">
            <div id="mainContent">