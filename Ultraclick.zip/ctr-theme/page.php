<?php
/**
 * The template for displaying all pages.
 *
 * @package WordPress
 * @subpackage CTR Theme
 * @since CTR Theme 1.0
 */

get_header(); ?>

			<div id="content" role="main">

            <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>

				<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<?php include(TEMPLATEPATH . '/includes/postBody.php'); ?>
				</div><!-- #post-## -->


            <?php endwhile; ?>

			</div><!-- #content -->
<?php get_footer(); ?>
