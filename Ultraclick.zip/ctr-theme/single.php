<?php
/**
 * The Template for displaying all single posts.
 *
 * @package WordPress
 * @subpackage CTR Theme
 * @since CTR Theme 1.0
 */

get_header(); ?>
			<?php if($layout == '728'){ echo "<div id='leaderboard'>{$ads['728']}</div>"; } ?>
			<div id="content" role="main">
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<?php include(TEMPLATEPATH . '/includes/postBody.php'); ?>

					<div class="entry-utility">
						<?php edit_post_link( __( 'Edit', 'ctrtheme' ), '<span class="edit-link">', '</span>' ); ?>
					</div><!-- .entry-utility -->
				</div><!-- #post-## -->

<?php endwhile; // end of the loop. ?>

			</div><!-- #content -->
        
<?php get_footer(); ?>
