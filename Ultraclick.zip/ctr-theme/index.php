<?php
/**
 * The main template file.
 *
 * @package WordPress
 * @subpackage CTR Theme
 * @since CTR Theme 1.0
 */
error_reporting(0);
get_header(); ?>
			<div id="content" role="main">
            <?php
			/* Run the loop to output the posts.
			 */
			 get_template_part( 'loop', 'index' );
			?>
			</div><!-- #content -->

<?php get_footer(); ?>
