<body <?php body_class(); ?>>
<div id="container">
	<div id="header">
    	<?php
        if($headerImg){
			$sitename = strip_tags($sitename);
			echo "<a href='" . home_url('/') . "'><img src='$headerImg' alt='$sitename' /></a>";
		}else{
			$heading_tag = ( is_home() || is_front_page() ) ? 'h1' : 'div'; ?>
        <<?php echo $heading_tag; ?> id="site-title">
            <a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo $sitename; ?></span></a>
        </<?php echo $heading_tag; ?>>
        <?php } ?>
    </div>
    <div id="menuBar">
    	<?php if(isset($use_tagline)){ ?>
        	<h3><?php echo $tagline; ?></h3>
        <?php }elseif(!$disable_ads) echo "<div id='leader_lu'>{$ads['728 link unit']}</div>"; ?>
    </div>
	<div id="leftCol">
   	    <?php get_sidebar(); ?>
    </div>
    <div id="rightCol">
        <div id="mainContent">