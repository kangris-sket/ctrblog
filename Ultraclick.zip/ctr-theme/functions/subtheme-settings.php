<?php error_reporting(0);
include_once('../../../../wp-config.php');
include_once('../../../../wp-load.php');
include_once('../../../../wp-includes/wp-db.php');
include_once('../functions.php');

$s = $_GET['subtheme'];

$path = TEMPLATEPATH . '/includes';
set_include_path(get_include_path() . PATH_SEPARATOR . $path);
include('Zend/Config/Ini.php');
$subtheme_dir = TEMPLATEPATH . '/ctr/subthemes/' . $s . '/';
$ss = new Zend_Config_Ini($subtheme_dir . 'config.ini');

$admin = $ss->admin;
echo json_encode($admin->hide_fields->toArray());
?>