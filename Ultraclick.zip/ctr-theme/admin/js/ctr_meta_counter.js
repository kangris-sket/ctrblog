jQuery(document).ready(function(){
	jQuery("#meta_desc_char_count").html(155 - jQuery("#ctr_meta_description").val().length);
	jQuery("#ctr_meta_description").keyup(function(){
		var charLength = jQuery(this).val().length;
		jQuery("#meta_desc_char_count").html(155 - charLength);
	});
});