<body <?php body_class(); ?>>
<div id="siteMenu">
	<?php if ( is_active_sidebar( 'top-nav' ) ) : ?>
		<div id="topNav" class="widget-area">
			<ul class="xoxo">
				<?php dynamic_sidebar( 'top-nav' ); ?>
			</ul>
		</div><!-- #topNav .widget-area -->
    <?php endif; ?>
</div>
<div id="container">
	<div id="header">
    	<?php
        if(isset($headerImg)){
			$sitename = strip_tags($sitename);
			echo "<img src='$headerImg' alt='$sitename' />";
		}else{
			$heading_tag = ( is_home() || is_front_page() ) ? 'h1' : 'div'; ?>
        <div id="branding">
        <<?php echo $heading_tag; ?> id="site-title">
            <a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo $sitename; ?></span></a>
        </<?php echo $heading_tag; ?>>
        </div>
        <?php } ?>
    </div>
    <div id="menuBar" style="background:<?php echo $lu_bg; ?>;">
    	<?php if($use_tagline || !$ads['728 link unit'] || !$layout){ echo "<h3 id='tagline'>$tagline</h3>"; }else echo "<div id='leader_lu'>{$ads['728 link unit']}</div>"; ?>
    </div>
    <div id="main">
        <div id="leftCol">
            <div id="mainContent">