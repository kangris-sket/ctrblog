<?php
            global $ctr_custom;
            global $show_comments;
            
            $pushdown1 = $pushdown2 = false;
            $pd1alt = $pd2alt = '';
            
            if((array_key_exists('ctr_disable_pushdown', $ctr_custom) && !$ctr_custom['ctr_disable_pushdown'][0]) || !array_key_exists('ctr_disable_pushdown', $ctr_custom)){
			    $pushdown1 = array_key_exists('ctr_ad_pushdown1', $ctr_custom) ? $ctr_custom['ctr_ad_pushdown1'][0] : get_option('ctr_ad_pushdown1');
			    $pushdown2 = array_key_exists('ctr_ad_pushdown2', $ctr_custom) ? $ctr_custom['ctr_ad_pushdown2'][0] : get_option('ctr_ad_pushdown2');
			    $pd1alt = array_key_exists('ctr_ad_pushdown1_alt', $ctr_custom) ? $ctr_custom['ctr_ad_pushdown1_alt'][0] : get_option('ctr_ad_pushdown1_alt');
			    $pd2alt = array_key_exists('ctr_ad_pushdown2_alt', $ctr_custom) ? $ctr_custom['ctr_ad_pushdown2_alt'][0] : get_option('ctr_ad_pushdown2_alt');
			    $pd1link = array_key_exists('ctr_ad_pushdown1_link', $ctr_custom) ? $ctr_custom['ctr_ad_pushdown1_link'][0] : get_option('ctr_ad_pushdown1_link');
			    $pd2link = array_key_exists('ctr_ad_pushdown2_link', $ctr_custom) ? $ctr_custom['ctr_ad_pushdown2_link'][0] : get_option('ctr_ad_pushdown2_link');
            }
			if($pushdown1 || $pushdown2)
			{
			    if($pd1link){
			        $pd1pre = "<a href=\"$pd1link\">";
			        $pd1post = "</a>";
			    }else{
			        $pd1pre = $pd1post = "";
			    }
			    if($pd2link){
			        $pd2pre = "<a href=\"$pd2link\">";
			        $pd2post = "</a>";
			    }else{
			        $pd2pre = $pd2post = "";
			    }
			    
				echo "<div id='pushdown' class='clearfix'>";
				if($pushdown1) echo "$pd1pre<img src='$pushdown1' alt='$pd1alt' class='pushdown' />$pd1post";
				if($pushdown2) echo "$pd2pre<img src='$pushdown2' alt='$pd2alt' class='pushdown' />$pd2post";
				echo "</div>";
			} ?>
            
            <?php if ( is_front_page() ) { ?>
				<h2 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php printf( esc_attr__( 'Permalink to %s', 'ctrtheme' ), the_title_attribute( 'echo=0' ) ); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
			<?php } else { ?>
				<h1 class="entry-title"><?php the_title(); ?></h1>
			<?php } ?>
			
			<div class="entry-content">
            	<?php include(TEMPLATEPATH . '/includes/ctrLayouts.php'); ?>
				<?php wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'ctrtheme' ), 'after' => '</div>' ) ); ?>
			</div><!-- .entry-content -->
			
						
			<?php if(is_single() && $show_comments) comments_template( '', true ); ?>