<body <?php body_class(); ?>>
<div id="container">
	<div id="logo">
        <?php $heading_tag = ( is_home() || is_front_page() ) ? 'h1' : 'div'; ?>
        <<?php echo $heading_tag; ?> id="site-title">
            <a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo $sitename; ?></span></a>
        </<?php echo $heading_tag; ?>>
    </div>
	<div id="leftCol" class="shadow">
   	    <?php get_sidebar(); ?>
    </div>
    <div id="rightCol" class="shadow">
    	<div id="topBar">
        	<?php if($use_tagline || !$ads['728 link unit'] || !$layout){ echo "<h3 id='tagline'>$tagline</h3>"; }else echo "<div id='leader_lu'>{$ads['728 link unit']}</div>"; ?>
        </div>
        <div id="mainContent">