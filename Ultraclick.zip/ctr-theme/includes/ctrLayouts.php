<?php global $layout; global $ads; ?>
<?php if($layout == 'roadblock'){ ?>
                            <div class="roadblock"><?php echo $ads['336']; ?></div>
                            <div class="roadblock"><?php echo $ads['336']; ?></div>
                            <?php the_content(); ?>
                        <?php }elseif($layout == '336-left' || $layout == '728'){ ?>
                        	<div class="adsense336">
								<?php echo $ads['336']; ?>
                            </div>
                    		<?php the_content(); ?>
                    	<?php }elseif($layout == '336-right'){ ?>
                        	<div class="adsense336 right">
								<?php echo $ads['336']; ?>
                            </div>
                    		<?php the_content(); ?>
                        <?php }elseif($layout == 'doublestack-left'){ ?>
							<div class="adsense336 left">
                            	<?php echo $ads['336']; ?><br /><?php echo $ads['336']; ?>
                            </div>
                            <?php the_content(); ?>
						<?php }elseif($layout == 'doublestack-right'){ ?>
							<div class="adsense336 right">
                            	<?php echo $ads['336']; ?><br /><?php echo $ads['336']; ?>
                            </div>
                            <?php the_content(); ?>
						<?php }elseif(!$layout || $layout == 'bottomblock') the_content(); ?>
						
                        <?php if($layout && ($layout == '336-left' || $layout == '336-right' || $layout == '728')){ 
							echo "<div class='adsense336block'>{$ads['336']}</div>";
						}elseif($layout && $layout == 'bottomblock'){
							echo "<div class='roadblock'>{$ads['336']}</div><div class='roadblock'>{$ads['336']}</div>";
						}?>