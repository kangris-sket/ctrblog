jQuery(document).ready(function($) {
	var lcol_height = $("#leftCol").height() + 80; // add 80 for margin + padding
	var rcol_height = $("#rightCol").height();
	
	if(rcol_height > lcol_height) $("#leftCol").css('height',(rcol_height - 80) + 'px');
	else $("#rightCol").css('height',lcol_height + 'px');
});