		</div><!-- #mainContent -->
    </div><!-- #rightCol -->
    <div style="clear:both;"></div>
</div><!-- #container -->
<div id="footer" class="clearfix">
    <div id="colophon">
        <div id="site-info">
            &copy; <?php echo date('Y'); ?> <a href="<?php echo home_url( '/' ) ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
                <?php bloginfo( 'name' ); ?>
            </a>
        </div><!-- #site-info -->
        <div id="privacy-info">
            <?php if ( is_active_sidebar( 'footer-privacy' ) ) : ?>
    			<ul class="xoxo">
    				<?php dynamic_sidebar( 'footer-privacy' ); ?>
    			</ul>
            <?php endif; ?>
        </div>

    </div><!-- #colophon -->
</div><!-- #footer -->