<?php
/**
 * The Sidebar containing the primary and secondary widget areas.
 *
 * @package WordPress
 * @subpackage CTR Theme
 * @since CTR Theme 1.0
 */
?>

		<div id="primary" class="widget-area" role="complementary">
			<ul class="xoxo">
<?php
	// A widget area appearing above the 160x600 ad block (at the very top of the sidebar
			dynamic_sidebar( 'left-col-above-160' ); ?>
        	<?php global $ads; global $layout; if($layout){ ?>
        	<li> <?php echo $ads['160']; ?></li>
            <?php } ?>
            
			</ul>
		</div><!-- #primary .widget-area -->

<?php
	// A second sidebar for widgets, appearing below the 160x600 ad block.
	if ( is_active_sidebar( 'left-col-below-160' ) ) : ?>

		<div id="secondary" class="widget-area" role="complementary">
			<ul class="xoxo">
				<?php dynamic_sidebar( 'left-col-below-160' ); ?>
			</ul>
		</div><!-- #secondary .widget-area -->

<?php
else:
global $post;
$orig = $post;

$sideposts = new WP_Query('showposts=10');
$sidenav = "<div id='secondary' role='complementary'><ul class='xoxo'>";
while($sideposts->have_posts()) : $sideposts->the_post();
    $sidenav .= "<li><a href='" . get_permalink() . "'>" . get_the_title() . "</a></li>";
endwhile;
$sidenav .= "</ul></div>";
echo $sidenav;

$post = $orig;
endif;
?>
