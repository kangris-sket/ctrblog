<?php error_reporting(0);
include_once('../../../../wp-config.php');
include_once('../../../../wp-load.php');
include_once('../../../../wp-includes/wp-db.php'); ?>
    jQuery(document).ready(function(){
		jQuery('.rm_options').slideUp();
		
		jQuery('.rm_section h3').click(function(){		
			if(jQuery(this).parent().next('.rm_options').css('display')=='none')
				{	jQuery(this).removeClass('inactive');
					jQuery(this).addClass('active');
					jQuery(this).children('img').removeClass('inactive');
					jQuery(this).children('img').addClass('active');
					
				}
			else
				{	jQuery(this).removeClass('active');
					jQuery(this).addClass('inactive');		
					jQuery(this).children('img').removeClass('active');			
					jQuery(this).children('img').addClass('inactive');
				}
				
			jQuery(this).parent().next('.rm_options').slideToggle('slow');	
		});

		checkColorOpts();

		jQuery('#ctr_ad_color_override').change(function(){
			checkColorOpts();
		});
		
		jQuery('#ctr_channel_tracking').change(function(){
			checkAdChannels();
		});

		// Hide fields based on selected theme
		var activetheme = jQuery("input:radio[name=ctr_ad_subtheme]:checked").val();
		showHideFields();
		

		// Add code to change hidden fields based on theme changes
        jQuery("input:radio[name=ctr_ad_subtheme]").change(function(){
        	activetheme = jQuery(this).val();
            showHideFields();
        });
        
        function showHideFields()
        {
        	jQuery.getJSON("<?php echo get_bloginfo('template_directory') ?>" + "/functions/subtheme-settings.php", { subtheme: activetheme }, function(data){
               jQuery(".rm_input").show();
               for(field in data)
               {
                   jQuery("#" + data[field]).parent().parent().hide();
               }
               checkColorOpts();
               checkAdChannels();
            });
        }
        
        function checkColorOpts()
        {
        	if(jQuery('#ctr_ad_color_override:checked').val() == undefined)
			{
				hideColorOpts();
			}else{
				showColorOpts();
			}
        }
        
        function checkAdChannels()
        {
        	if(jQuery('#ctr_channel_tracking:checked').val() == undefined)
			{
				hideAdChannels();
			}else{
				showAdChannels();
			}
        }
        
        function hideColorOpts()
        {
        	jQuery('#ctr_ad_sitebg').parent().parent().hide();
        	
            jQuery('#ctr_ad_linkcolor').parent().parent().hide();
            jQuery('#ctr_ad_urlcolor').parent().parent().hide(); 
            jQuery('#ctr_ad_bg').parent().parent().hide();
            jQuery('#ctr_ad_text').parent().parent().hide();
            jQuery('#ctr_ad_border').parent().parent().hide();
            
            jQuery('#ctr_container_bg').parent().parent().hide();
            jQuery('#ctr_lcol_bg').parent().parent().hide();
            jQuery('#ctr_rcol_bg').parent().parent().hide();
            jQuery('#ctr_menubar_bg').parent().parent().hide();
            
            jQuery('#ctr_ad_lu_link').parent().parent().hide();
            jQuery('#ctr_ad_lu_url').parent().parent().hide();
            jQuery('#ctr_ad_lu_bg').parent().parent().hide();
            jQuery('#ctr_ad_lu_text').parent().parent().hide();
            jQuery('#ctr_ad_lu_border').parent().parent().hide();
        }
        
        function showColorOpts()
        {
        	jQuery('#ctr_ad_sitebg').parent().parent().show();
        	
        	jQuery('#ctr_ad_linkcolor').parent().parent().show();
            jQuery('#ctr_ad_urlcolor').parent().parent().show();
            jQuery('#ctr_ad_bg').parent().parent().show();
            jQuery('#ctr_ad_text').parent().parent().show();
            jQuery('#ctr_ad_border').parent().parent().show();
            
            jQuery('#ctr_container_bg').parent().parent().show();
            jQuery('#ctr_lcol_bg').parent().parent().show();
            jQuery('#ctr_rcol_bg').parent().parent().show();
            jQuery('#ctr_menubar_bg').parent().parent().show();
            
            jQuery('#ctr_ad_lu_link').parent().parent().show();
            jQuery('#ctr_ad_lu_url').parent().parent().show();
            jQuery('#ctr_ad_lu_bg').parent().parent().show();
            jQuery('#ctr_ad_lu_text').parent().parent().show();
            jQuery('#ctr_ad_lu_border').parent().parent().show();
        }
        
        function hideAdChannels()
        {
        	jQuery('#ctr_roadblock_channel').parent().parent().hide();
        	jQuery('#ctr_336-left_channel').parent().parent().hide();
        	jQuery('#ctr_336-right_channel').parent().parent().hide();
        	jQuery('#ctr_728_channel').parent().parent().hide();
        	jQuery('#ctr_doublestack-left_channel').parent().parent().hide();
        	jQuery('#ctr_doublestack-right_channel').parent().parent().hide();
        	jQuery('#ctr_bottomblock_channel').parent().parent().hide();
        }
        
        function showAdChannels()
        {
        	jQuery('#ctr_roadblock_channel').parent().parent().show();
        	jQuery('#ctr_336-left_channel').parent().parent().show();
        	jQuery('#ctr_336-right_channel').parent().parent().show();
        	jQuery('#ctr_728_channel').parent().parent().show();
        	jQuery('#ctr_doublestack-left_channel').parent().parent().show();
        	jQuery('#ctr_doublestack-right_channel').parent().parent().show();
        	jQuery('#ctr_bottomblock_channel').parent().parent().show();
        }
        
});