<?php
/**
 * The template for displaying the footer.
 *
 * @package WordPress
 * @subpackage CTR Theme
 * @since CTR Theme 1.0
 */
 global $subtheme_dir;
 include($subtheme_dir . 'footer.php');
 wp_footer();
?>
</body>
</html>
